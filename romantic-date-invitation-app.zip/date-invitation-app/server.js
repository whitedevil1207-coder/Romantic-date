const express = require("express");
const path = require("path");
const Database = require("better-sqlite3");

const app = express();
const PORT = process.env.PORT || 3000;
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || "change-this-password";

const db = new Database(path.join(__dirname, "responses.db"));
db.pragma("journal_mode = WAL");

db.exec(`
  CREATE TABLE IF NOT EXISTS responses (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    answer TEXT NOT NULL,
    food TEXT,
    date TEXT,
    time TEXT,
    place TEXT,
    message TEXT,
    created_at TEXT NOT NULL
  )
`);

app.use(express.json({ limit: "20kb" }));
app.use(express.urlencoded({ extended: false, limit: "20kb" }));

app.use(express.static(path.join(__dirname, "public")));

app.post("/api/response", (req, res) => {
  const allowedAnswers = new Set(["yes", "maybe", "no"]);
  const { answer, food = "", date = "", time = "", place = "", message = "" } = req.body || {};

  if (!allowedAnswers.has(answer)) {
    return res.status(400).json({ error: "Invalid answer." });
  }

  const clean = value => String(value ?? "").trim().slice(0, 1000);

  const stmt = db.prepare(`
    INSERT INTO responses (answer, food, date, time, place, message, created_at)
    VALUES (?, ?, ?, ?, ?, ?, ?)
  `);

  const result = stmt.run(
    answer,
    clean(food),
    clean(date),
    clean(time),
    clean(place),
    clean(message),
    new Date().toISOString()
  );

  res.json({ ok: true, id: result.lastInsertRowid });
});

app.get("/admin", (req, res) => {
  res.sendFile(path.join(__dirname, "private", "responses.html"));
});

function requireAdmin(req, res, next) {
  const password = req.get("x-admin-password");

  if (!password || password !== ADMIN_PASSWORD) {
    return res.status(401).json({ error: "Unauthorized" });
  }

  next();
}

app.get("/api/admin/responses", requireAdmin, (req, res) => {
  const rows = db.prepare(`
    SELECT id, answer, food, date, time, place, message, created_at
    FROM responses
    ORDER BY id DESC
  `).all();

  res.json(rows);
});

app.delete("/api/admin/responses/:id", requireAdmin, (req, res) => {
  const id = Number(req.params.id);

  if (!Number.isInteger(id)) {
    return res.status(400).json({ error: "Invalid ID." });
  }

  db.prepare("DELETE FROM responses WHERE id = ?").run(id);
  res.json({ ok: true });
});

app.listen(PORT, () => {
  console.log(`Date app running on port ${PORT}`);
});
